// =========================================================
// === JOGO: GUARDIÕES DA FLORESTA (COM EMOJIS) p5.js ===
// =========================================================

// Variáveis Globais
let player;
let trees = [];    // Array para armazenar as árvores
let axes = [];     // Array para armazenar os machados
let flames = [];   // Array para armazenar os projéteis de fogo
let soldiers = []; // Array para armazenar os soldados
let temperature = 30; // Temperatura inicial do planeta (ex: 30 graus Celsius)
let coins = 0;     // Moedas do jogador

// Estados do Jogo: 'menu', 'playing', 'gameOver', 'gameWin', 'shop'
let gameState = 'menu';

// Configurações dos emojis
const EMOJI_SIZE = 32;

// --- Emojis ---
const EMOJI_PLAYER = '🧑‍🌾';
const EMOJI_TREE_NORMAL = '🌳';
const EMOJI_TREE_ZOMBIE = '🧟';
const EMOJI_AXE = '🪓';
const EMOJI_FLAME = '🔥';
const EMOJI_TEMP_HOT = '🥵';
const EMOJI_TEMP_NORMAL = '🙂';
const EMOJI_TEMP_COLD = '🥶';
const EMOJI_PLANET = '🌎'; // Para a capa
const EMOJI_SOLDIER = '💂'; // Emoji de soldado
const EMOJI_COIN = '💰'; // Emoji de moeda

// =======================
// === Classes do Jogo ===
// =======================

// --- Classe Player ---
class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 50;
    this.speed = 5;
    this.plantCooldown = 0;
    this.plantDelay = 30; // Frames de espera entre plantios
    this.shootCooldown = 0;
    this.shootDelay = 15; // Frames de espera entre tiros
  }

  show() {
    textSize(EMOJI_SIZE);
    textAlign(CENTER, CENTER);
    text(EMOJI_PLAYER, this.x, this.y);
  }

  move() {
    if (keyIsDown(LEFT_ARROW) && this.x > EMOJI_SIZE / 2) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW) && this.x < width - EMOJI_SIZE / 2) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW) && this.y > EMOJI_SIZE / 2) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW) && this.y < height - EMOJI_SIZE / 2) {
      this.y += this.speed;
    }

    if (this.plantCooldown > 0) this.plantCooldown--;
    if (this.shootCooldown > 0) this.shootCooldown--;
  }

  plantTree() {
    if (this.plantCooldown <= 0) {
      trees.push(new Tree(this.x, this.y));
      this.plantCooldown = this.plantDelay;
      // temperature -= 0.5; // REMOVIDO: Temperatura não abaixa ao plantar
      temperature = max(0, temperature); // Garante que a temperatura não seja negativa
    }
  }

  shootFlame() {
    if (this.shootCooldown <= 0) {
      flames.push(new Flame(this.x, this.y - EMOJI_SIZE / 2));
      this.shootCooldown = this.shootDelay;
    }
  }
}

// --- Classe Tree ---
class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.isZombie = false;
    this.health = 100; // Vida da árvore zumbi
    this.infectionCooldown = 0;
    this.infectionDelay = 60;
    this.zombieSpeed = 0.7;
  }

  show() {
    textSize(EMOJI_SIZE);
    textAlign(CENTER, CENTER);
    if (this.isZombie) {
      text(EMOJI_TREE_ZOMBIE, this.x, this.y);
    } else {
      text(EMOJI_TREE_NORMAL, this.x, this.y);
    }
  }

  cut() {
    this.isZombie = true;
    temperature += 2;
  }

  infect(otherTree) {
    if (!otherTree.isZombie && this.infectionCooldown <= 0) {
      otherTree.isZombie = true;
      temperature += 2;
      this.infectionCooldown = this.infectionDelay;
    }
  }

  receiveDamage(amount) {
    this.health -= amount;
    if (this.health <= 0) {
      return true; // Retorna true se a árvore foi destruída
    }
    return false;
  }

  update() {
    if (this.isZombie) {
      if (this.infectionCooldown > 0) this.infectionCooldown--;

      let closestNormalTree = null;
      let minDist = Infinity;

      for (let otherTree of trees) {
        if (this != otherTree && !otherTree.isZombie) {
          let d = dist(this.x, this.y, otherTree.x, otherTree.y);
          if (d < minDist) {
            minDist = d;
            closestNormalTree = otherTree;
          }
        }
      }

      if (closestNormalTree) {
        let angle = atan2(closestNormalTree.y - this.y, closestNormalTree.x - this.x);
        this.x += cos(angle) * this.zombieSpeed;
        this.y += sin(angle) * this.zombieSpeed;

        if (dist(this.x, this.y, closestNormalTree.x, closestNormalTree.y) < EMOJI_SIZE) {
          this.infect(closestNormalTree);
        }
      }

      if (this.infectionCooldown <= 0) {
        for (let otherTree of trees) {
          if (this != otherTree && dist(this.x, this.y, otherTree.x, otherTree.y) < EMOJI_SIZE * 1.5) {
            this.infect(otherTree);
            break;
          }
        }
      }
    }
  }
}

// --- Classe Axe (Machado) ---
class Axe {
  constructor() {
    this.x = random(width);
    this.y = -EMOJI_SIZE; // Começa acima da tela
    this.speed = random(1.5, 3.5);
    this.targetTree = null;
  }

  show() {
    textSize(EMOJI_SIZE);
    textAlign(CENTER, CENTER);
    text(EMOJI_AXE, this.x, this.y);
  }

  move() {
    // Se o machado ainda não tem um alvo ou se o alvo virou zumbi/foi destruído
    if (!this.targetTree || this.targetTree.isZombie || trees.indexOf(this.targetTree) === -1) {
      // Encontra a árvore normal mais próxima
      let closestNormalTree = null;
      let minDist = Infinity;

      for (let otherTree of trees) {
        if (!otherTree.isZombie) { // Apenas árvores normais
          let d = dist(this.x, this.y, otherTree.x, otherTree.y);
          if (d < minDist) {
            minDist = d;
            closestNormalTree = otherTree;
          }
        }
      }
      this.targetTree = closestNormalTree; // Define o novo alvo
    }

    // Se houver um alvo, move-se em direção a ele
    if (this.targetTree) {
      let angle = atan2(this.targetTree.y - this.y, this.targetTree.x - this.x);
      this.x += cos(angle) * this.speed;
      this.y += sin(angle) * this.speed;
    } else {
      // Se não há árvores normais (todas zumbis ou nenhuma), move-se para baixo
      this.y += this.speed;
    }
  }

  offscreen() {
    return this.y > height + EMOJI_SIZE || this.x < -EMOJI_SIZE || this.x > width + EMOJI_SIZE;
  }
}

// --- Classe Flame (Projétil do Lança-chamas) ---
class Flame {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.speed = 8;
    this.damage = 100; // Dano que causa às árvores zumbis (mata em um ataque)
  }

  show() {
    textSize(EMOJI_SIZE);
    textAlign(CENTER, CENTER);
    text(EMOJI_FLAME, this.x, this.y);
  }

  move() {
    this.y -= this.speed;
  }

  offscreen() {
    return this.y < -EMOJI_SIZE;
  }
}

// --- Classe Soldier ---
class Soldier {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.damage = 100; // Dano do soldado (mata zumbi em um ataque)
    this.shootCooldown = 0;
    this.shootDelay = 60; // Tempo entre tiros do soldado (1 segundo)
    this.range = 200; // Alcance do soldado para atirar em zumbis
  }

  show() {
    textSize(EMOJI_SIZE);
    textAlign(CENTER, CENTER);
    text(EMOJI_SOLDIER, this.x, this.y);
  }

  update() {
    if (this.shootCooldown > 0) {
      this.shootCooldown--;
    }

    // Encontrar zumbi mais próximo dentro do alcance
    let closestZombie = null;
    let minDist = this.range;

    for (let tree of trees) {
      if (tree.isZombie) {
        let d = dist(this.x, this.y, tree.x, tree.y);
        if (d < minDist) {
          minDist = d;
          closestZombie = tree;
        }
      }
    }

    // Se encontrou um zumbi e o cooldown permite, atira
    if (closestZombie && this.shootCooldown <= 0) {
      // Causa dano ao zumbi
      if (closestZombie.receiveDamage(this.damage)) {
        // Se o zumbi for destruído pelo soldado
        let zombieIndex = trees.indexOf(closestZombie);
        if (zombieIndex > -1) {
          trees.splice(zombieIndex, 1);
          temperature -= 1; // Destruir zumbi reduz a temperatura
          coins += 1; // Zumbi derruba 1 moeda
        }
      }
      this.shootCooldown = this.shootDelay;
    }
  }
}

// ===================
// === Funções p5.js ===
// ===================

function setup() {
  createCanvas(800, 600); // LARGURA DA TELA AUMENTADA
  player = new Player();
  rectMode(CENTER);
  imageMode(CENTER);
}

function draw() {
  background(135, 206, 235); // Céu azul claro

  // --- Lógica de Estados do Jogo ---
  if (gameState === 'menu') {
    drawMenu();
  } else if (gameState === 'playing') {
    drawGame();
  } else if (gameState === 'shop') {
    // Quando na loja, desenha o jogo, mas a lógica principal de update está congelada em drawGame()
    drawGame(); // Desenha os elementos do jogo como estão, mas não atualiza
    drawShop(); // Desenha a loja por cima
  } else if (gameState === 'gameOver') {
    displayGameOver();
  } else if (gameState === 'gameWin') {
    displayGameWin();
  }
}

// --- Funções de Desenho para os Estados ---

function drawMenu() {
  background(20, 20, 50); // Fundo escuro para o menu
  fill(255);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("GUARDIÕES DA FLORESTA", width / 2, height / 2 - 100);

  textSize(100);
  text(EMOJI_PLANET, width / 2, height / 2); // Emoji do planeta no centro

  textSize(24);
  text("Plante árvores 🌳 e salve o planeta 🌎", width / 2, height / 2 + 100);
  text("Pressione ENTER para começar", width / 2, height / 2 + 140);

  textSize(16);
  textAlign(LEFT, TOP);
  fill(200);
  text("Controles:", 20, height - 150);
  text("Setas: Mover 🧑‍🌾", 20, height - 120);
  text("Z: Plantar Árvore 🌳", 20, height - 100);
  text("X: Lança-chamas 🔥", 20, height - 80);
  text("P: Abrir/Fechar Loja 🏪", 20, height - 60);
  text("C (na loja): Comprar Soldado 💂", 20, height - 40);
}

function drawGame() {
  // === A MAIOR PARTE DA LÓGICA SÓ RODA SE O JOGO NÃO ESTIVER NA LOJA ===
  if (gameState === 'playing') {
    // Jogador
    player.move();

    // Soldados
    for (let i = soldiers.length - 1; i >= 0; i--) {
      soldiers[i].update();
    }

    // Árvores
    for (let i = trees.length - 1; i >= 0; i--) {
      trees[i].update(); // Lógica de infecção e movimento para zumbis

      // Colisão Machados vs. Árvores
      for (let j = axes.length - 1; j >= 0; j--) {
        if (!trees[i].isZombie &&
            dist(trees[i].x, trees[i].y, axes[j].x, axes[j].y) < EMOJI_SIZE) {
          trees[i].cut(); // Transforma em zombi
          axes.splice(j, 1); // Remove o machado (machado "usado")
          break; // Sai do loop interno, pois o machado já colidiu
        }
      }

      // Colisão Chamas vs. Árvores Zumbis
      if (trees[i].isZombie) {
        for (let k = flames.length - 1; k >= 0; k--) {
          if (dist(trees[i].x, trees[i].y, flames[k].x, flames[k].y) < EMOJI_SIZE / 2) {
            if (trees[i].receiveDamage(flames[k].damage)) {
              // Árvore zumbi destruída!
              trees.splice(i, 1); // Remove a árvore zumbi
              temperature -= 1; // Destruir zumbi reduz a temperatura
              coins += 1; // Zumbi derruba 1 moeda
              flames.splice(k, 1); // Remove a chama
              break;
            }
            flames.splice(k, 1); // Remove a chama mesmo que não destrua a árvore (hit)
            break;
          }
        }
      }
    }

    // Machados
    for (let i = axes.length - 1; i >= 0; i--) {
      axes[i].move();
      if (axes[i].offscreen()) {
        axes.splice(i, 1);
      }
    }

    // Projéteis de Fogo
    for (let i = flames.length - 1; i >= 0; i--) {
      flames[i].move();
      if (flames[i].offscreen()) {
        flames.splice(i, 1);
      }
    }

    // Aparição de machados (a cada X frames)
    if (frameCount % 240 === 0 && axes.length < 5) {
      axes.push(new Axe());
    }

    // Aumentar temperatura gradualmente
    temperature += 0.005;
    temperature = min(temperature, 50);

    // Condições de Game Over/Win
    checkGameStatus();
  } // Fim do IF `gameState === 'playing'`

  // === Desenho dos elementos (sempre ocorre, mesmo na loja) ===
  player.show();

  for (let soldier of soldiers) {
    soldier.show();
  }

  for (let tree of trees) {
    tree.show();
  }

  for (let axe of axes) {
    axe.show();
  }

  for (let flame of flames) {
    flame.show();
  }

  // Exibir UI de status (sempre ocorre)
  displayTemperature();
  displayCoins();
}


// --- Funções de Eventos ---
function keyPressed() {
  if (gameState === 'menu') {
    if (keyCode === ENTER) {
      gameState = 'playing';
      resetGame();
    }
  } else if (gameState === 'playing') {
    if (key === 'z' || key === 'Z') {
      player.plantTree();
    }
    if (key === 'x' || key === 'X') {
      player.shootFlame();
    }
    if (key === 'p' || key === 'P') { // Abrir a loja
      gameState = 'shop';
    }
  } else if (gameState === 'shop') {
    if (key === 'p' || key === 'P') { // Fechar a loja
      gameState = 'playing';
    }
    if ((key === 'c' || key === 'C') && coins >= 5) { // Comprar Soldado
      soldiers.push(new Soldier(random(50, width - 50), random(height / 2 + 50, height - 100)));
      coins -= 5;
    }
  } else if (gameState === 'gameOver' || gameState === 'gameWin') {
    if (keyCode === ENTER) {
      gameState = 'menu';
      resetGame();
    }
  }
}


// --- Funções de UI/Status ---

function displayTemperature() {
  let tempEmoji = EMOJI_TEMP_NORMAL;
  let tempColor = color(0);

  if (temperature >= 40) {
    tempEmoji = EMOJI_TEMP_HOT;
    tempColor = color(255, 0, 0);
  } else if (temperature < 20) {
    tempEmoji = EMOJI_TEMP_COLD;
    tempColor = color(0, 0, 255);
  }

  fill(tempColor);
  textSize(24);
  textAlign(LEFT, TOP);
  text(`Temp: ${temperature.toFixed(1)}°C ${tempEmoji}`, 10, 10);

  let normalTrees = trees.filter(t => !t.isZombie).length;
  let zombieTrees = trees.filter(t => t.isZombie).length;
  text(`🌳: ${normalTrees}  🧟: ${zombieTrees}`, 10, 40);
}

function displayCoins() {
  fill(255, 200, 0); // Cor de moeda (amarelo/laranja)
  textSize(24);
  textAlign(RIGHT, TOP);
  text(`${coins} ${EMOJI_COIN}`, width - 10, 10);
  text(`💂: ${soldiers.length}`, width - 10, 40);
}

function drawShop() {
  background(50, 50, 80, 220); // Fundo escuro transparente para a loja
  fill(255);
  textSize(40);
  textAlign(CENTER, CENTER);
  text("LOJA", width / 2, height / 2 - 150);

  textSize(24);
  text(`Moedas: ${coins} ${EMOJI_COIN}`, width / 2, height / 2 - 90);

  // Opções de compra
  // Opção: Comprar Soldado
  fill(0, 150, 0); // Cor de fundo do botão
  rect(width / 2, height / 2, 250, 60, 10); // Botão do soldado com cantos arredondados
  fill(255);
  text("Comprar Soldado 💂", width / 2, height / 2 - 10);
  textSize(18);
  text("(5 Moedas)", width / 2, height / 2 + 15);


  textSize(18);
  textAlign(CENTER, CENTER);
  fill(200);
  text("Pressione 'P' para sair da loja", width / 2, height / 2 + 200);
}

function checkGameStatus() {
  let normalTreesCount = trees.filter(t => !t.isZombie).length;
  let zombieTreesCount = trees.filter(t => t.isZombie).length;

  if (temperature >= 50) {
    gameState = 'gameOver';
  }
  if (trees.length > 0 && normalTreesCount === 0) {
    gameState = 'gameOver';
  }

  if (temperature <= 10 && normalTreesCount >= 10) {
    gameState = 'gameWin';
  }
}

function displayGameOver() {
  background(255, 0, 0, 150);
  fill(255);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("GAME OVER!", width / 2, height / 2 - 30);
  textSize(24);
  text("O planeta ferveu!", width / 2, height / 2 + 20);
  text("Pressione ENTER para voltar ao menu", width / 2, height / 2 + 60);
}

function displayGameWin() {
  background(0, 255, 0, 150);
  fill(255);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("VITÓRIA!", width / 2, height / 2 - 30);
  textSize(24);
  text("Você salvou o planeta!", width / 2, height / 2 + 20);
  text("Pressione ENTER para voltar ao menu", width / 2, height / 2 + 60);
}

// --- Função para Reiniciar o Jogo ---
function resetGame() {
  player = new Player();
  trees = [];
  axes = [];
  flames = [];
  soldiers = []; // Limpa os soldados também
  temperature = 30;
  coins = 0; // Zera as moedas
}